# Veterinary Clinic Scraper - Improved Version

This is an improved version of the veterinary clinic scraper that extracts data from local.ch website using Selenium WebDriver.

## Key Improvements Made

### 1. Enhanced Selenium WebDriver Setup
- Added anti-detection measures to avoid being blocked
- Improved user agent and browser options
- Better error handling for WebDriver initialization
- Added page load timeout settings

### 2. Fixed Data Structure
- Updated data structure to match the Excel output format exactly
- Added missing fields: `Title`, `Address`, `description`
- Ensured all required columns are present in the output

### 3. Improved Error Handling
- Enhanced retry mechanisms with exponential backoff
- Better timeout handling for page loads
- Multiple fallback selectors for critical elements
- Graceful error recovery and checkpoint saving

### 4. Better Data Extraction
- Added description extraction with multiple selector fallbacks
- Improved address parsing and formatting
- Enhanced opening hours extraction
- Better text cleaning and formatting functions

### 5. Enhanced Progress Tracking
- Better logging with timestamps
- Progress indicators during scraping
- Checkpoint saving every 5 records
- Random delays to avoid rate limiting

### 6. Excel Export Functionality
- Added `export_to_excel()` method
- Ensures proper column ordering
- Handles missing columns gracefully
- Exports both complete and partial results

## Files Structure

- `app.py` - Main scraper script with all improvements
- `requirements.txt` - Required Python packages
- `test_scraper.py` - Test script for validation
- `veterinary_clinics.csv` - Input CSV with clinic links
- `ScrapeLocal.ch.xlsx` - Expected output format reference

## Installation

1. Install required packages:
```bash
pip install -r requirements.txt
```

2. Make sure you have Chrome browser installed
3. ChromeDriver will be automatically managed by Selenium

## Usage

### Basic Usage
```python
from app import VetDetailScraper

scraper = VetDetailScraper()
scraper.scrape_from_links('veterinary_clinics.csv')
```

### Run the Test
```bash
python test_scraper.py
```

### Run Full Scraping
```bash
python app.py
```

## Output

The scraper will generate:
- `scraped_results.xlsx` - Complete results in Excel format
- `scraping_checkpoint.csv` - Progress checkpoint file
- `scraping_log_YYYYMMDD_HHMMSS.log` - Detailed logging

## Data Fields Extracted

The scraper extracts the following fields to match the Excel format:

- `url` - Original URL
- `Title` - Business title
- `Address` - Full address string
- `logo_url` - Logo image URL
- `title` - Business name
- `street` - Street address
- `zipcode` - Postal code
- `city` - City name
- `kanton` - Canton/state
- `phone_numbers` - Phone numbers
- `email` - Email address
- `website` - Website URL
- `description` - Business description
- `languages` - Languages spoken
- `Lundi` through `Dimanche` - Opening hours for each day

## Error Handling Features

- Automatic retry with exponential backoff
- Checkpoint saving on errors
- Graceful handling of missing elements
- Multiple selector fallbacks
- Random delays to avoid rate limiting
- Comprehensive logging

## Troubleshooting

1. **ChromeDriver Issues**: Make sure Chrome browser is installed and up to date
2. **Rate Limiting**: The script includes random delays, but you may need to increase them
3. **Missing Data**: Some fields might be empty if not available on the page
4. **Network Issues**: The script will retry failed requests automatically

## Performance Notes

- Processes approximately 1-2 pages per second
- Saves progress every 5 records
- Can resume from checkpoint if interrupted
- Uses headless browser for better performance
